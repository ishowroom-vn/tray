package qz.exception;

public class MissingArgException extends Exception {}
