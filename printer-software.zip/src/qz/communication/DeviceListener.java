package qz.communication;

public interface DeviceListener {

    void close();

}
