Please feel free to open bug reports on GitHub. Before opening an issue, we ask that you consider whether your issue is a support question, or a potential bug with the software.

If you have a support question, first [check the FAQ](https://qz.io/wiki/faq) and the [wiki](https://qz.io/wiki/Home).  If you cannot find a solution please reach out to one of the appropriate channels:

### Community Support

If you need assistance using the software and do not have a paid subscription, please reference our community support channel: https://qz.io/support/

### Premium Support

If you have an active support license with QZ Industries, LLC, please send support requests to support@qz.io
